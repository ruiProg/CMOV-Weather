# CMOV-Weather

#### Google Account used in Apixu:

username: cmovweather@gmail.com

pass: December14

#### API key:
48de77b9d0584523a65161204170812

#### Server with cities uses Flask:
http://flask.pocoo.org/

#### Populate server database (MySQL):
https://github.com/prograhammer/countries-regions-cities

#### Disable Hyper-V(to test in Android):
bcdedit /set hypervisorlaunchtype off

#### Enable Hyper-V (to test UWP):
bcdedit /set hypervisorlaunchtype auto 
